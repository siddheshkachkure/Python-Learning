school_name = "CDAC"    
duplicate_school_name = "CDAC"

if school_name is duplicate_school_name:
    print("Equal")
else:
    print("Not equal") 