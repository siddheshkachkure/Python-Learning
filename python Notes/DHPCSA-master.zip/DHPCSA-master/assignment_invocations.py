from assignment_definitions import *

#my_list_store()
#my_dict_store()
#my_set_store()
#fibonacci_range()