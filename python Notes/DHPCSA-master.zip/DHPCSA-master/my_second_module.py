

print("I am in second module")

# import my_first_module # importing the entire module  
from my_first_module import my_name,my_list  # import part of modules 
print("my_name in first module is ===>>>>>> " , my_name)
print("my_name in first module is ===>>>>>> " , my_list)

